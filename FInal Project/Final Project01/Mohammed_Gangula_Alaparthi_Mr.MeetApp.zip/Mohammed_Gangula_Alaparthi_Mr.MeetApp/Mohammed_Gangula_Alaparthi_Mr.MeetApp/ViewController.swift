//
//  ViewController.swift
//  Mohammed_Gangula_Alaparthi_Mr.MeetApp
//
//  Created by Navya Alaparthi on 4/22/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


   
    @IBOutlet weak var tableCell: UITableViewCell!
    
}

